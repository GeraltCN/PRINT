clear
syms t a;
int(sqrt(2)*(a^3)*((1-cos(t))^(3/2)), t, 0, 2*pi)
