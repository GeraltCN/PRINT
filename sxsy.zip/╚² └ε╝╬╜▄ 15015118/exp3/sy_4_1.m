clear
syms t a;
int(a*a, t, -pi/2, pi/2)
