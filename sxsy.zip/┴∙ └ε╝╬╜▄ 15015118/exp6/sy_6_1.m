clear
syms r f e
int(int(e^2, r, 1, 2), f, 0, 2*pi)
