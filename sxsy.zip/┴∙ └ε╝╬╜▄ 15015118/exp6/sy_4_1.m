clear
syms x y
3*int(int(x*(1-x-y), x, 0, 1), y, 1, 0)
