clear
syms z1 z2
[x y]  = solve(z1+2*z2-1-i, 3*z1+i*z2-2+3*i);

                                % ANS z1 = 1-i
                                %     z2 = i
