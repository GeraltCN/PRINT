clear
syms z
f = sin(1/(z-1));
r = limit(f*(z-1), z, 1);
R = r

                                % ANS 0

