function showLoss(X)
  nansum(X)
  nanmin(X)
  nanmax(X)
  nanmedian(X)
  nanstd(X)
end
