clear
X = binornd(20, 0.2)
[p, pci] = binofit(X, 20)
