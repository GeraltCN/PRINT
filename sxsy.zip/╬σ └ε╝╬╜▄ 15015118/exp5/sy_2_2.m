clear
syms r f;
int(int(2*r, r, 0, 1), f, 0, 2*pi)
