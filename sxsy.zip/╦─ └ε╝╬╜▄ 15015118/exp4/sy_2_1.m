clear
syms t a
int(sin(2*t), t, 0, 2*pi)
