clear
syms t
3*int(-(sin(t)^3+cos(t)^3), t, 0, pi/2)
