clear
syms t a
I1 = int(t+1, t, 0, 1);
I2 = int(t+2, t, 0, 1);
I3 = int(t+3, t, 0, 1);
I = I1 + I2 + I3
