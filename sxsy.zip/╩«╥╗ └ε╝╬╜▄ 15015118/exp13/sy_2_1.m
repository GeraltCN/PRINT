clear
fun = 'x^2+4*x+4';
[X fval exitflag output] = fminsearch(fun, 0)
