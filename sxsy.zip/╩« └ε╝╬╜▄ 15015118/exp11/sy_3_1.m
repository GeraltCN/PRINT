clear
format short
x0 = [0.1 0.1]
fsolve(@gg, x0)
