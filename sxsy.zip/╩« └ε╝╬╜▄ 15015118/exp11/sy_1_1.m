clear
fun = inline('x-exp(-x)','x');
fsolve(fun, [rand()])
