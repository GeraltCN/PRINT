clear
syms r f;
int(int(1, r, 0, sin(f)/(cos(f)*cos(f))), f, 0, pi/4)
