clear
syms r f;
int(int(r*r*r, r, 0, sqrt(2)), f, 0, pi/4)
