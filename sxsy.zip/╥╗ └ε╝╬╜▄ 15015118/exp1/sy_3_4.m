clear
syms r f;
int(int(r, r, 1-sin(f), cos(3*f)), f, -pi/3, pi/3)
