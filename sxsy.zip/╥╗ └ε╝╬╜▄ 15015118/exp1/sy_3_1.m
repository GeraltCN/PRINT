clear
syms r f;
int(int(r, r, 0, cos(3*f)), f, -pi/3, pi/3)
