clear
syms r f;
int(int(r, r, 0, 1-sin(f)), f, 0, 2*pi)
