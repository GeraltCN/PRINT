clear
syms x y;
f = x / (1+x*y);
int(int(f, y, 0, 1), x, 0，1)
