                                % 目标函数
function f = objfun(x)
  f = 1/3*(x(1)+1)^3+x(2);
end
