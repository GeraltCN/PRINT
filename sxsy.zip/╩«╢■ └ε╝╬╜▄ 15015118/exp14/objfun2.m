                                % 目标函数
function f = objfun2(x)
  f = 2*x(1)^2+2*x(x)^2-2*x(1)*x(2)-4*x(1)-6*x(2);
end
